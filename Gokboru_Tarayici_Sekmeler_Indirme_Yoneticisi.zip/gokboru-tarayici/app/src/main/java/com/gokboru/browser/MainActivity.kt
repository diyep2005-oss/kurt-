package com.gokboru.browser

import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.app.DownloadManager
import android.Manifest
import android.content.pm.PackageManager
import android.content.Intent
import android.net.Uri
import android.os.Environment
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.graphics.Color
import android.graphics.Typeface
import android.database.Cursor
import android.webkit.CookieManager
import android.webkit.URLUtil
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.*

class MainActivity : Activity() {
    private val navy = Color.rgb(4, 13, 23)
    private val panel = Color.rgb(8, 25, 39)
    private val gold = Color.rgb(246, 181, 39)
    private val pale = Color.rgb(231, 239, 248)

    private lateinit var address: EditText
    private lateinit var status: TextView
    private lateinit var home: LinearLayout
    private lateinit var browserArea: FrameLayout
    private lateinit var tabStrip: LinearLayout
    private lateinit var downloadButton: TextView

    private data class BrowserTab(val id: Int, val web: WebView, var isHome: Boolean = true, var title: String = "Yeni sekme")
    private val tabs = mutableListOf<BrowserTab>()
    private var activeTabId = 0
    private var nextTabId = 1
    private var desktop = false
    private var adBlock = true
    private var nightMode = false
    private var incognitoMode = false
    private var normalUserAgent: String? = null

    private data class PendingDownload(val url: String, val userAgent: String, val contentDisposition: String?, val mimeType: String?)
    private var pendingDownload: PendingDownload? = null
    private val storagePermissionRequest = 7401
    private val handler = Handler(Looper.getMainLooper())
    private var downloadsDialog: AlertDialog? = null
    private var downloadsContainer: LinearLayout? = null
    private val downloadRefresh = object : Runnable {
        override fun run() {
            if (downloadsDialog?.isShowing == true) {
                refreshDownloadRows()
                handler.postDelayed(this, 900)
            }
        }
    }

    private val activeTab: BrowserTab
        get() = tabs.first { it.id == activeTabId }
    private val web: WebView
        get() = activeTab.web

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = navy
        window.navigationBarColor = navy

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(navy)
        }
        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(10), dp(8), dp(10), dp(8))
            setBackgroundColor(panel)
        }
        val logo = TextView(this).apply {
            text = "☪"; textSize = 27f; setTextColor(gold); setPadding(dp(4), 0, dp(8), 0)
        }
        address = EditText(this).apply {
            hint = "Google'da ara veya adres gir"
            setSingleLine(true); textSize = 14f
            setTextColor(pale); setHintTextColor(0xff8c9aa8.toInt())
            setPadding(dp(14), 0, dp(10), 0); setBackgroundColor(0xff102638.toInt())
            imeOptions = EditorInfo.IME_ACTION_GO
            setSelectAllOnFocus(true)
            setOnEditorActionListener { _, action, _ ->
                if (action == EditorInfo.IME_ACTION_GO || action == EditorInfo.IME_ACTION_DONE) {
                    navigate(text.toString()); true
                } else false
            }
        }
        val go = button("Git", gold, navy) { navigate(address.text.toString()) }
        top.addView(logo)
        top.addView(address, LinearLayout.LayoutParams(0, dp(44), 1f))
        top.addView(go, LinearLayout.LayoutParams(dp(54), dp(44)))
        root.addView(top)

        tabStrip = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(5), dp(4), dp(5), dp(4))
            setBackgroundColor(0xff030a11.toInt())
        }
        root.addView(tabStrip, LinearLayout.LayoutParams(-1, dp(46)))

        browserArea = FrameLayout(this)
        home = buildHome()
        browserArea.addView(home, FrameLayout.LayoutParams(-1, -1))
        root.addView(browserArea, LinearLayout.LayoutParams(-1, 0, 1f))

        val bottom = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setBackgroundColor(0xff030a11.toInt())
            setPadding(dp(4), dp(5), dp(4), dp(5))
        }
        bottom.addView(navButton("‹") { if (web.canGoBack()) web.goBack() })
        bottom.addView(navButton("›") { if (web.canGoForward()) web.goForward() })
        bottom.addView(navButton("⌂") { showHome() })
        bottom.addView(navButton("▢") { showTabsDialog() })
        downloadButton = navButton("↓") { openDownloads() }
        bottom.addView(downloadButton)
        bottom.addView(navButton("☰") { showMenu() })
        root.addView(bottom)

        status = TextView(this).apply {
            text = "GÖKBÖRÜ • Hazır"; textSize = 10f; setTextColor(gold)
            gravity = Gravity.CENTER; setPadding(0, dp(3), 0, dp(5)); setBackgroundColor(navy)
        }
        root.addView(status)
        setContentView(root)

        createTab(showHome = true)
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun createTab(showHome: Boolean = true, initialUrl: String? = null) {
        val id = nextTabId++
        val browser = WebView(this).apply {
            setBackgroundColor(Color.WHITE)
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.loadsImagesAutomatically = true
            settings.useWideViewPort = true
            settings.loadWithOverviewMode = true
            if (normalUserAgent == null) normalUserAgent = settings.userAgentString
            webViewClient = object : WebViewClient() {
                override fun onPageStarted(view: WebView?, url: String?, favicon: android.graphics.Bitmap?) {
                    val tab = tabs.firstOrNull { it.id == id } ?: return
                    tab.isHome = false
                    if (id == activeTabId) {
                        address.setText(url ?: "")
                        status.text = "Yükleniyor…"
                    }
                    updateTabStrip()
                }
                override fun onPageFinished(view: WebView?, url: String?) {
                    val tab = tabs.firstOrNull { it.id == id } ?: return
                    tab.title = view?.title?.takeIf { it.isNotBlank() } ?: url?.let { Uri.parse(it).host } ?: "Sekme"
                    if (id == activeTabId) {
                        status.text = "Hazır"
                        address.setText(url ?: "")
                    }
                    updateTabStrip()
                }
                override fun onReceivedTitle(view: WebView?, title: String?) {
                    tabs.firstOrNull { it.id == id }?.title = title?.takeIf { it.isNotBlank() } ?: "Sekme"
                    updateTabStrip()
                }
            }
            webChromeClient = WebChromeClient()
            setDownloadListener { url, userAgent, contentDisposition, mimeType, _ ->
                startDownload(url, userAgent ?: settings.userAgentString, contentDisposition, mimeType)
            }
        }
        val tab = BrowserTab(id, browser, showHome)
        tabs.add(tab)
        browserArea.addView(browser, FrameLayout.LayoutParams(-1, -1))
        if (tabs.size == 1 || showHome) activateTab(id)
        if (initialUrl != null) {
            tab.isHome = false
            browser.loadUrl(initialUrl)
        } else if (showHome) {
            browser.visibility = View.GONE
            home.visibility = View.VISIBLE
        }
        updateTabStrip()
    }

    private fun activateTab(id: Int) {
        val selected = tabs.firstOrNull { it.id == id } ?: return
        activeTabId = id
        tabs.forEach { it.web.visibility = if (it.id == id && !it.isHome) View.VISIBLE else View.GONE }
        home.visibility = if (selected.isHome) View.VISIBLE else View.GONE
        address.setText(if (selected.isHome) "" else selected.web.url ?: "")
        status.text = if (selected.isHome) "GÖKBÖRÜ • Ana sayfa" else "Hazır"
        updateTabStrip()
    }

    private fun closeTab(id: Int) {
        val index = tabs.indexOfFirst { it.id == id }
        if (index < 0) return
        val wasActive = id == activeTabId
        val removed = tabs.removeAt(index)
        browserArea.removeView(removed.web)
        removed.web.stopLoading()
        removed.web.destroy()
        if (tabs.isEmpty()) {
            createTab(showHome = true)
            return
        }
        if (wasActive) {
            val next = tabs[(index - 1).coerceAtLeast(0)]
            activateTab(next.id)
        } else updateTabStrip()
    }

    private fun updateTabStrip() {
        if (!::tabStrip.isInitialized) return
        tabStrip.removeAllViews()
        val horizontalScroll = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            fillViewport = false
        }
        val items = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        tabs.forEach { tab ->
            val item = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(8), dp(3), dp(4), dp(3))
                background = rounded(if (tab.id == activeTabId) 0xff17364a.toInt() else 0xff091521.toInt(), gold, 10)
            }
            val label = TextView(this).apply {
                text = (tab.title.ifBlank { "Yeni sekme" }).take(13)
                textSize = 11f; setTextColor(if (tab.id == activeTabId) gold else pale)
                maxLines = 1; maxWidth = dp(108)
                setOnClickListener { activateTab(tab.id) }
            }
            val close = TextView(this).apply {
                text = " × "; textSize = 16f; setTextColor(pale)
                setPadding(dp(3), 0, dp(2), 0)
                setOnClickListener { closeTab(tab.id) }
            }
            item.addView(label)
            item.addView(close)
            item.setOnClickListener { activateTab(tab.id) }
            val lp = LinearLayout.LayoutParams(-2, dp(34))
            lp.setMargins(dp(3), 0, dp(3), 0)
            items.addView(item, lp)
        }
        horizontalScroll.addView(items)
        tabStrip.addView(horizontalScroll, LinearLayout.LayoutParams(0, -1, 1f))
        val add = button("+", gold, navy) { createTab(showHome = true) }
        add.textSize = 23f
        tabStrip.addView(add, LinearLayout.LayoutParams(dp(40), dp(36)))
    }

    private fun showTabsDialog() {
        val names = tabs.mapIndexed { index, tab ->
            "${if (tab.id == activeTabId) "● " else ""}${index + 1}. ${tab.title.ifBlank { "Yeni sekme" }}"
        }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Sekmeler (${tabs.size})")
            .setItems(names) { _, which -> if (which in tabs.indices) activateTab(tabs[which].id) }
            .setNeutralButton("＋ Yeni sekme") { _, _ -> createTab(showHome = true) }
            .setNegativeButton("Kapat", null)
            .show()
    }

    private fun buildHome(): LinearLayout {
        val scroller = ScrollView(this)
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(20), dp(20), dp(20), dp(18))
            background = android.graphics.drawable.GradientDrawable(
                android.graphics.drawable.GradientDrawable.Orientation.TL_BR,
                intArrayOf(0xff061726.toInt(), 0xff0b2c40.toInt(), 0xff050d16.toInt())
            )
        }
        val emblem = ImageView(this).apply {
            setImageDrawable(android.graphics.drawable.Drawable.createFromStream(assets.open("gokboru-emblem-original.png"), null))
            scaleType = ImageView.ScaleType.FIT_CENTER
        }
        content.addView(emblem, LinearLayout.LayoutParams(dp(154), dp(154)))
        content.addView(text("GÖKBÖRÜ", 29f, gold, true))
        content.addView(text("SELÇUKLU TARZI TARAYICI", 12f, 0xffffd979.toInt(), true))
        val search = EditText(this).apply {
            hint = "Web'de ara veya adres yaz"; setSingleLine(true); textSize = 15f
            setTextColor(pale); setHintTextColor(0xff91a3b2.toInt()); setPadding(dp(14), 0, dp(14), 0)
            setBackgroundColor(0xff102638.toInt()); imeOptions = EditorInfo.IME_ACTION_GO
            setOnEditorActionListener { _, action, _ ->
                if (action == EditorInfo.IME_ACTION_GO || action == EditorInfo.IME_ACTION_DONE) { navigate(text.toString()); true } else false
            }
        }
        val searchLp = LinearLayout.LayoutParams(-1, dp(48)); searchLp.setMargins(0, dp(18), 0, dp(18))
        content.addView(search, searchLp)
        val grid = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val row1 = LinearLayout(this); val row2 = LinearLayout(this)
        row1.addView(tile("★", "Favoriler") { Toast.makeText(this@MainActivity, "Favoriler yakında eklenecek", Toast.LENGTH_SHORT).show() })
        row1.addView(tile("◷", "Geçmiş") { Toast.makeText(this@MainActivity, "Geçmiş yakında eklenecek", Toast.LENGTH_SHORT).show() })
        row1.addView(tile("▣", "Sekmeler") { showTabsDialog() })
        row1.addView(tile("⚙", "Ayarlar") { showMenu() })
        row2.addView(tile("▯", "Telefon") { desktop = false; web.settings.useWideViewPort = true; Toast.makeText(this@MainActivity, "Telefon görünümü seçildi", Toast.LENGTH_SHORT).show() })
        row2.addView(tile("▱", "Bilgisayar") { toggleDesktopMode() })
        row2.addView(tile("◉", "Gizli mod") { toggleIncognito() })
        row2.addView(tile("⬟", "İndirilenler") { openDownloads() })
        grid.addView(row1); grid.addView(row2); content.addView(grid)
        content.addView(text("Hızlı erişim", 16f, gold, true))
        val links = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        links.addView(button("Google", gold, navy) { navigate("https://www.google.com") })
        links.addView(button("YouTube", gold, navy) { navigate("https://m.youtube.com") })
        links.addView(button("Wikipedia", gold, navy) { navigate("https://tr.wikipedia.org") })
        content.addView(links)
        scroller.addView(content)
        return LinearLayout(this).apply { addView(scroller) }
    }

    private fun tile(symbol: String, label: String, action: () -> Unit): View {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
            setPadding(dp(3), dp(8), dp(3), dp(8))
            background = rounded(0xff091b2a.toInt(), 0xff204b63.toInt(), 12)
            setOnClickListener { action() }
        }
        box.addView(text(symbol, 24f, gold, true))
        box.addView(text(label, 10f, pale, true))
        val lp = LinearLayout.LayoutParams(0, dp(88), 1f); lp.setMargins(dp(3), dp(4), dp(3), dp(4))
        box.layoutParams = lp
        return box
    }

    private fun rounded(color: Int, stroke: Int, radius: Int) =
        android.graphics.drawable.GradientDrawable().apply {
            setColor(color); setStroke(dp(1), stroke); cornerRadius = dp(radius).toFloat()
        }

    private fun text(value: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = value; textSize = size; setTextColor(color); gravity = Gravity.CENTER
        if (bold) typeface = Typeface.DEFAULT_BOLD
        setPadding(dp(3), dp(4), dp(3), dp(4))
    }

    private fun button(label: String, bg: Int, fg: Int, action: () -> Unit) = TextView(this).apply {
        text = label; textSize = 12f; gravity = Gravity.CENTER; setTextColor(fg); setBackgroundColor(bg)
        setPadding(dp(8), dp(10), dp(8), dp(10)); setOnClickListener { action() }
    }

    private fun navButton(label: String, action: () -> Unit) = TextView(this).apply {
        text = label; textSize = 25f; gravity = Gravity.CENTER; setTextColor(pale)
        layoutParams = LinearLayout.LayoutParams(0, dp(42), 1f); setOnClickListener { action() }
    }

    private fun navigate(input: String) {
        var target = input.trim()
        if (target.isEmpty()) return
        if (!target.contains("://")) {
            target = if (target.contains(".") && !target.contains(" ")) "https://$target"
            else "https://www.google.com/search?q=" + java.net.URLEncoder.encode(target, "UTF-8")
        }
        activeTab.isHome = false
        home.visibility = View.GONE
        tabs.forEach { it.web.visibility = if (it.id == activeTabId) View.VISIBLE else View.GONE }
        web.loadUrl(target)
        updateTabStrip()
    }

    private fun showHome() {
        web.stopLoading()
        activeTab.isHome = true
        web.visibility = View.GONE
        home.visibility = View.VISIBLE
        address.setText("")
        status.text = "GÖKBÖRÜ • Ana sayfa"
        updateTabStrip()
    }

    private fun showMenu() {
        val items = arrayOf(
            "Ana sayfa", "Yeni sekme", "Sekmeleri yönet", "İndirilenler",
            "Reklam engelleme: " + if (adBlock) "Açık" else "Kapalı",
            if (desktop) "Telefon görünümüne geç" else "Bilgisayar görünümüne geç",
            if (nightMode) "Gece filtresini kapat" else "Gece filtresini aç",
            "Sayfayı Türkçeye çevir", "Bağlantıyı paylaş", "Gizli gezinme: " + if (incognitoMode) "Açık" else "Kapalı",
            "Tarama verilerini temizle", "Hakkında"
        )
        AlertDialog.Builder(this).setTitle("☪ Gökbörü Tarayıcı").setItems(items) { _, which ->
            when (which) {
                0 -> showHome()
                1 -> createTab(showHome = true)
                2 -> showTabsDialog()
                3 -> openDownloads()
                4 -> { adBlock = !adBlock; Toast.makeText(this, "Reklam engelleme: ${if (adBlock) "Açık" else "Kapalı"} (filtre motoru ayrıca gerekir)", Toast.LENGTH_LONG).show() }
                5 -> toggleDesktopMode()
                6 -> toggleNightMode()
                7 -> translateCurrentPage()
                8 -> shareCurrentPage()
                9 -> toggleIncognito()
                10 -> clearBrowsingData()
                11 -> AlertDialog.Builder(this).setMessage("Gökbörü Tarayıcı\nÇoklu sekme ve indirme yöneticisi etkin.").setPositiveButton("Tamam", null).show()
            }
        }.setNegativeButton("Kapat", null).show()
    }

    private fun toggleDesktopMode() {
        desktop = !desktop
        val base = normalUserAgent ?: web.settings.userAgentString
        web.settings.userAgentString = if (desktop) base.replace("Mobile", "X11").replace("Android", "Linux") else base
        web.settings.useWideViewPort = desktop
        web.settings.loadWithOverviewMode = !desktop
        Toast.makeText(this, if (desktop) "Bilgisayar görünümü açıldı" else "Telefon görünümü açıldı", Toast.LENGTH_SHORT).show()
        if (!activeTab.isHome) web.reload()
    }

    private fun toggleNightMode() {
        nightMode = !nightMode
        if (!activeTab.isHome) {
            val js = if (nightMode) "(function(){document.documentElement.style.filter='invert(0.88) hue-rotate(180deg)';document.querySelectorAll('img,video,iframe').forEach(function(e){e.style.filter='invert(1) hue-rotate(180deg)'})})()"
            else "(function(){document.documentElement.style.filter='';document.querySelectorAll('img,video,iframe').forEach(function(e){e.style.filter=''})})()"
            web.evaluateJavascript(js, null)
        }
        Toast.makeText(this, if (nightMode) "Gece filtresi açıldı" else "Gece filtresi kapatıldı", Toast.LENGTH_SHORT).show()
    }

    private fun translateCurrentPage() {
        val url = web.url
        if (activeTab.isHome || url.isNullOrBlank()) {
            Toast.makeText(this, "Önce çevrilecek bir sayfa aç", Toast.LENGTH_SHORT).show(); return
        }
        navigate("https://translate.google.com/translate?sl=auto&tl=tr&u=" + java.net.URLEncoder.encode(url, "UTF-8"))
    }

    private fun shareCurrentPage() {
        val url = web.url
        if (activeTab.isHome || url.isNullOrBlank()) {
            Toast.makeText(this, "Paylaşılacak sayfa yok", Toast.LENGTH_SHORT).show(); return
        }
        val share = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"; putExtra(Intent.EXTRA_TEXT, url); putExtra(Intent.EXTRA_SUBJECT, web.title ?: "Gökbörü Tarayıcı")
        }
        startActivity(Intent.createChooser(share, "Sayfayı paylaş"))
    }

    private fun toggleIncognito() {
        incognitoMode = !incognitoMode
        if (incognitoMode) {
            tabs.forEach { it.web.clearHistory(); it.web.clearCache(true) }
            CookieManager.getInstance().removeAllCookies(null)
            CookieManager.getInstance().flush()
            tabs.forEach { it.web.settings.cacheMode = android.webkit.WebSettings.LOAD_NO_CACHE }
            Toast.makeText(this, "Gizli oturum açıldı. Bu basit mod ayrı profil izolasyonu sağlamaz.", Toast.LENGTH_LONG).show()
            createTab(showHome = true)
        } else {
            tabs.forEach { it.web.settings.cacheMode = android.webkit.WebSettings.LOAD_DEFAULT; it.web.clearHistory(); it.web.clearCache(true) }
            CookieManager.getInstance().removeAllCookies(null)
            CookieManager.getInstance().flush()
            Toast.makeText(this, "Gizli oturum kapatıldı; çerezler temizlendi.", Toast.LENGTH_SHORT).show()
        }
    }

    private fun clearBrowsingData() {
        AlertDialog.Builder(this).setTitle("Tarama verilerini temizle?")
            .setMessage("Açık sekmelerin geçmişi, önbelleği ve çerezler temizlenecek.")
            .setNegativeButton("Vazgeç", null)
            .setPositiveButton("Temizle") { _, _ ->
                tabs.forEach { it.web.clearHistory(); it.web.clearCache(true) }
                CookieManager.getInstance().removeAllCookies { CookieManager.getInstance().flush() }
                Toast.makeText(this, "Tarama verileri temizlendi", Toast.LENGTH_SHORT).show()
            }.show()
    }

    private fun startDownload(url: String, userAgent: String, contentDisposition: String?, mimeType: String?) {
        if (url.isBlank()) return
        if (android.os.Build.VERSION.SDK_INT <= 28 &&
            checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            pendingDownload = PendingDownload(url, userAgent, contentDisposition, mimeType)
            requestPermissions(arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE), storagePermissionRequest)
            return
        }
        try {
            val filename = URLUtil.guessFileName(url, contentDisposition, mimeType)
            val request = DownloadManager.Request(Uri.parse(url)).apply {
                setTitle(filename)
                setDescription("Gökbörü Tarayıcı")
                setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, filename)
                setAllowedOverMetered(true)
                setAllowedOverRoaming(true)
                if (mimeType != null) setMimeType(mimeType)
                if (userAgent.isNotBlank()) addRequestHeader("User-Agent", userAgent)
                val cookie = CookieManager.getInstance().getCookie(url)
                if (!cookie.isNullOrBlank()) addRequestHeader("Cookie", cookie)
            }
            val manager = getSystemService(DOWNLOAD_SERVICE) as DownloadManager
            manager.enqueue(request)
            Toast.makeText(this, "İndirme başladı: $filename", Toast.LENGTH_LONG).show()
            if (downloadsDialog?.isShowing == true) refreshDownloadRows()
        } catch (e: Exception) {
            Toast.makeText(this, "İndirme başlatılamadı: ${e.localizedMessage ?: "bilinmeyen hata"}", Toast.LENGTH_LONG).show()
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == storagePermissionRequest) {
            val download = pendingDownload
            pendingDownload = null
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED && download != null) {
                startDownload(download.url, download.userAgent, download.contentDisposition, download.mimeType)
            } else Toast.makeText(this, "İndirme için depolama izni gerekli", Toast.LENGTH_LONG).show()
        }
    }

    private fun openDownloads() {
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(8), dp(16), dp(8))
            setBackgroundColor(navy)
        }
        downloadsContainer = content
        val scroll = ScrollView(this).apply { addView(content) }
        downloadsDialog = AlertDialog.Builder(this)
            .setTitle("İndirme yöneticisi")
            .setView(scroll)
            .setPositiveButton("Kapat", null)
            .setNeutralButton("İndirilenler klasörü") { _, _ ->
                try { startActivity(Intent(DownloadManager.ACTION_VIEW_DOWNLOADS)) }
                catch (_: Exception) { Toast.makeText(this, "Dosyalar Android'in İndirilenler klasöründedir.", Toast.LENGTH_LONG).show() }
            }
            .create()
        downloadsDialog?.setOnDismissListener {
            handler.removeCallbacks(downloadRefresh)
            downloadsContainer = null
        }
        downloadsDialog?.show()
        refreshDownloadRows()
        handler.postDelayed(downloadRefresh, 900)
    }

    private fun refreshDownloadRows() {
        val container = downloadsContainer ?: return
        container.removeAllViews()
        val manager = getSystemService(DOWNLOAD_SERVICE) as DownloadManager
        var cursor: Cursor? = null
        try {
            cursor = manager.query(DownloadManager.Query())
            if (cursor == null || !cursor.moveToFirst()) {
                container.addView(text("Henüz indirme yok.", 14f, pale))
                return
            }
            do {
                val id = cursor.getLong(cursor.getColumnIndexOrThrow(DownloadManager.COLUMN_ID))
                val title = cursor.getString(cursor.getColumnIndexOrThrow(DownloadManager.COLUMN_TITLE)) ?: "Dosya"
                val statusIndex = cursor.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS)
                val statusValue = cursor.getInt(statusIndex)
                val total = cursor.getLong(cursor.getColumnIndexOrThrow(DownloadManager.COLUMN_TOTAL_SIZE_BYTES))
                val soFar = cursor.getLong(cursor.getColumnIndexOrThrow(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR))
                val reason = cursor.getInt(cursor.getColumnIndexOrThrow(DownloadManager.COLUMN_REASON))
                val percent = if (total > 0) ((soFar * 100L) / total).toInt().coerceIn(0, 100) else -1
                val state = when (statusValue) {
                    DownloadManager.STATUS_PENDING -> "Bekliyor"
                    DownloadManager.STATUS_RUNNING -> "İndiriliyor"
                    DownloadManager.STATUS_PAUSED -> "Duraklatıldı"
                    DownloadManager.STATUS_SUCCESSFUL -> "Tamamlandı"
                    DownloadManager.STATUS_FAILED -> "Başarısız (kod $reason)"
                    else -> "Bilinmiyor"
                }
                val row = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL
                    setPadding(dp(10), dp(8), dp(10), dp(8))
                    background = rounded(panel, 0xff204b63.toInt(), 10)
                }
                row.addView(text(title, 13f, gold, true))
                row.addView(text("$state${if (percent >= 0) " • %$percent" else ""}", 12f, pale))
                if (statusValue == DownloadManager.STATUS_RUNNING || statusValue == DownloadManager.STATUS_PENDING || statusValue == DownloadManager.STATUS_PAUSED) {
                    val progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
                        max = 100; this.progress = percent.coerceAtLeast(0)
                    }
                    row.addView(progress, LinearLayout.LayoutParams(-1, dp(7)))
                    val cancel = button("İndirmeyi iptal et", 0xff7f1d1d.toInt(), Color.WHITE) {
                        manager.remove(id)
                        refreshDownloadRows()
                    }
                    row.addView(cancel)
                } else if (statusValue == DownloadManager.STATUS_SUCCESSFUL) {
                    row.addView(button("Dosyayı aç", gold, navy) {
                        try {
                            val uri = manager.getUriForDownloadedFile(id)
                            if (uri != null) {
                                val mime = manager.getMimeTypeForDownloadedFile(id) ?: "*/*"
                                startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(uri, mime).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION))
                            } else Toast.makeText(this, "Dosya bulunamadı", Toast.LENGTH_SHORT).show()
                        } catch (_: Exception) {
                            Toast.makeText(this, "Bu dosyayı açacak uygulama bulunamadı", Toast.LENGTH_SHORT).show()
                        }
                    })
                }
                val lp = LinearLayout.LayoutParams(-1, -2)
                lp.setMargins(0, 0, 0, dp(8))
                container.addView(row, lp)
            } while (cursor.moveToNext())
        } catch (e: Exception) {
            container.addView(text("İndirmeler okunamadı: ${e.localizedMessage ?: "hata"}", 13f, pale))
        } finally {
            cursor?.close()
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        if (web.visibility == View.VISIBLE && web.canGoBack()) web.goBack()
        else if (!activeTab.isHome) showHome()
        else if (tabs.size > 1) closeTab(activeTabId)
        else super.onBackPressed()
    }

    override fun onDestroy() {
        handler.removeCallbacks(downloadRefresh)
        tabs.toList().forEach { it.web.stopLoading(); it.web.destroy() }
        tabs.clear()
        if (incognitoMode) {
            CookieManager.getInstance().removeAllCookies(null)
            CookieManager.getInstance().flush()
        }
        super.onDestroy()
    }
}
